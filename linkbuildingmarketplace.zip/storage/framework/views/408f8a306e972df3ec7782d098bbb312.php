<!doctype html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>
</head>

<body>
    <h1 class="text-4xl font-bold text-green-600">
        Hello world!
    </h1>
</body>

</html>
<?php /**PATH D:\Projects\React JS\linkbuildingmarketplace\resources\views\test.blade.php ENDPATH**/ ?>